#ifndef NORMALIZAR_H_INCLUDED
#define NORMALIZAR_H_INCLUDED

char* normalizar(char* cadDest, const char* cadOrig);
char* normalizarI(char* cadDest, const char* cadOrig);
#endif // NORMALIZAR_H_INCLUDED
